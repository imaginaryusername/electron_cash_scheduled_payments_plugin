from electroncash.i18n import _

fullname = 'Schedular Payments'
description = _('Manages scheduled payments.  Requires Electron Cash version >= 3.2')
available_for = ['qt']
